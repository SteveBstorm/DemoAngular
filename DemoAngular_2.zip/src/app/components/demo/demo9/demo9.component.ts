import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo9',
  templateUrl: './demo9.component.html',
  styleUrls: ['./demo9.component.scss']
})
export class Demo9Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
