export class Article {
    isChecked: boolean;

    constructor(public item:string, public count: number) {}
}