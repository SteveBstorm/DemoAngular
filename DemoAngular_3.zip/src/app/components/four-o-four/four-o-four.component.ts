import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-four-o-four',
  templateUrl: './four-o-four.component.html',
  styleUrls: ['./four-o-four.component.scss']
})
export class FourOFourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
